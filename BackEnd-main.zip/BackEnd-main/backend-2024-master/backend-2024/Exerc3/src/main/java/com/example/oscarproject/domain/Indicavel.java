package com.example.oscarproject.domain;

public interface Indicavel {
    void indicar();
}
