**EXECÍCIOS DE BACKEND 2024**

Neste repositório será encontrado arquivos contendo todos os exercícios feitos nas aulas de backend do ano de 2024
