package com.twitterclone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TwittercloneApplicationTests {

	@Test
	void contextLoads() {
	}

}
