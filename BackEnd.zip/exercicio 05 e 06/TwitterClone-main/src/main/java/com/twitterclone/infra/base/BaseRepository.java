package com.twitterclone.infra.base;

import org.springframework.stereotype.Repository;

@Repository
public abstract class BaseRepository {
}
