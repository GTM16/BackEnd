package com.twitterclone.infra.base;

import org.springframework.web.bind.annotation.RestController;

@RestController
public abstract class BaseController {
}
