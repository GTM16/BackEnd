package com.twitterclone.api;

import com.twitterclone.infra.base.BaseController;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PessoaController extends BaseController {
}
