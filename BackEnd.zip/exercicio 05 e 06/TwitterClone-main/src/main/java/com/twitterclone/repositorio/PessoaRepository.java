package com.twitterclone.repositorio;

import com.twitterclone.infra.base.BaseRepository;
import org.springframework.stereotype.Repository;

@Repository
public class PessoaRepository extends BaseRepository {
}
