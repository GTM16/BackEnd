package com.twitterclone.infra.base;

import org.springframework.stereotype.Service;

@Service
public abstract class BaseService {
}
