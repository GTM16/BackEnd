package com.twitterclone.dominio.enums;

public enum Sexo {
    Masculino,
    Feminino,
    Indefinido
}
