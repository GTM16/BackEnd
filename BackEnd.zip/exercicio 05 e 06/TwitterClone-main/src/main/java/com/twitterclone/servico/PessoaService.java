package com.twitterclone.servico;

import com.twitterclone.infra.base.BaseService;
import org.springframework.stereotype.Service;

@Service
public class PessoaService extends BaseService {
}
