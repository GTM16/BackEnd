package com.example.exemploTransacao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExemploTransacaoApplicationTests {

	@Test
	void contextLoads() {
	}

}
