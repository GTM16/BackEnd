package com.example.exerc9;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Exerc9Application {

	public static void main(String[] args) {
		SpringApplication.run(Exerc9Application.class, args);
	}

}
