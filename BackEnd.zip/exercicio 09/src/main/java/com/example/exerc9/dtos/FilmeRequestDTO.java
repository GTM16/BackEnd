package com.example.exerc9.dtos;

public record FilmeRequestDTO(
        String titulo,
        String diretor,
        int ano) {
}