package com.example.exerc9.dtos;

public record FilmeResponseDTO(
        Long id,
        String titulo,
        String diretor,
        int ano) {
}